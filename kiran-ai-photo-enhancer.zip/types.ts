
export interface ImageData {
  id: string;
  originalUrl: string;
  enhancedUrl?: string;
  mimeType: string;
  status: 'pending' | 'processing' | 'success' | 'error';
  error?: string;
}

export interface EnhancementResult {
  originalUrl: string;
  enhancedUrl: string;
  timestamp: number;
}

export enum AppStatus {
  IDLE = 'IDLE',
  PREVIEW = 'PREVIEW',
  PROCESSING = 'PROCESSING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export interface EnhancementOptions {
  strength: number;
  denoise: boolean;
  upscale: boolean;
}
