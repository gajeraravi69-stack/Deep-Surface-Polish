
import { GoogleGenAI } from "@google/genai";

export const enhanceImage = async (
  base64Image: string, 
  mimeType: string, 
  customInstructions: string = "", 
  useProMode: boolean = false
): Promise<string> => {
  // Always create a new instance to ensure we use the latest API key from the environment
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const modelName = useProMode ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  
  try {
    const userFocus = customInstructions 
      ? `AESTHETIC GOAL: ${customInstructions}` 
      : "Standard high-fidelity material scan.";

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          {
            text: `Act as a "Master Digital Conservator". Your task is to perform a High-Fidelity Surface Reconstruction on this asset. 
            
            ${userFocus}
            
            TECHNICAL REQUIREMENTS:
            1. SURFACE HARMONIZATION: Analyze the surface data. If there are any areas with inconsistent patterns, noise, or non-natural texture data, reconstruct those segments to perfectly match the surrounding organic or industrial grain. Ensure the surface is perfectly unified and clean.
            2. PHOTOMETRIC ENHANCEMENT: Increase the effective resolution. Synthesize realistic micro-shadows and specular highlights.
            3. CHROMATIC UNIFICATION: Correct any color aberrations or JPEG compression blockiness to ensure professional-grade color depth.
            4. SHARPNESS: Apply localized edge-definition to the primary subject while maintaining a natural depth of field.
            
            Strict Constraint: Output ONLY the processed image data as an inlineData part. Do not include any text, disclaimers, or explanations.`,
          },
        ],
      },
      config: useProMode ? {
        imageConfig: {
          imageSize: "4K",
          aspectRatio: "1:1"
        }
      } : undefined
    });

    const candidates = response.candidates;
    if (!candidates || candidates.length === 0) {
      throw new Error("Neural Engine Refusal: Content complexity or safety filter triggered.");
    }

    const parts = candidates[0].content?.parts;
    if (!parts) {
      throw new Error("Empty Payload: No reconstruction data returned.");
    }

    // Search for the image part
    for (const part of parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }

    const textPart = parts.find(p => p.text)?.text;
    if (textPart) {
      if (textPart.toLowerCase().includes("cannot fulfill") || textPart.toLowerCase().includes("policy")) {
         throw new Error("Neural Guardrail: This specific image pattern is currently restricted. Try a photo with fewer artificial overlays.");
      }
      throw new Error("Engine Refusal: " + textPart.substring(0, 100));
    }
    
    throw new Error("Reconstruction failed: Data stream interrupted.");
  } catch (error: any) {
    if (error.message?.includes("Requested entity was not found")) {
      throw new Error("API_KEY_ERROR: Please re-select your Paid API Key.");
    }
    console.error("Kiran AI Error Log:", error);
    throw error;
  }
};
