
import React, { useState, useRef, useEffect } from 'react';
import { AppStatus, ImageData } from './types';
import { enhanceImage } from './services/geminiService';
import ComparisonSlider from './components/ComparisonSlider';
import ProcessingOverlay from './components/ProcessingOverlay';

const QUICK_PROMPTS = [
  { label: "✨ Texture Sync", text: "Harmonize the surface texture to be perfectly consistent. Reconstruct any non-natural patches to match the surrounding background details." },
  { label: "💎 Ultra-Detail", text: "Hyper-enhance micro-facets, material shine, and high-frequency surface reflections." },
  { label: "📸 Portrait Pro", text: "Full facial geometry reconstruction, skin-tone unification, and iris detail sharpening." },
  { label: "🚀 Deep 4K", text: "Maximum resolution synthesis. Remove all compression artifacts and sharpen subject boundaries." }
];

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [batch, setBatch] = useState<ImageData[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState("");
  const [isProMode, setIsProMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const checkAndOpenKeySelector = async () => {
    // @ts-ignore
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
    }
    return true;
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    if (files.length > 10) {
      setError("Maximum 10 images allowed per batch.");
      return;
    }

    const validFiles = files.filter(f => f.type.startsWith('image/'));
    const newBatch: ImageData[] = [];
    let loadedCount = 0;

    validFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        newBatch.push({
          id: Math.random().toString(36).substr(2, 9),
          originalUrl: e.target?.result as string,
          mimeType: file.type,
          status: 'pending'
        });
        loadedCount++;
        if (loadedCount === validFiles.length) {
          setBatch(newBatch);
          setStatus(AppStatus.PREVIEW);
          setError(null);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const startBatchEnhancement = async () => {
    if (batch.length === 0) return;

    if (isProMode) {
      try {
        await checkAndOpenKeySelector();
      } catch (e) {
        setError("API Key selection failed. Pro mode requires a paid API key.");
        return;
      }
    }
    
    setStatus(AppStatus.PROCESSING);
    setError(null);
    
    const updatedBatch = [...batch];
    
    for (let i = 0; i < updatedBatch.length; i++) {
      setCurrentIndex(i);
      const img = updatedBatch[i];
      img.status = 'processing';
      setBatch([...updatedBatch]);

      try {
        const pureBase64 = img.originalUrl.split(',')[1];
        const enhanced = await enhanceImage(pureBase64, img.mimeType, customPrompt, isProMode);
        img.enhancedUrl = enhanced;
        img.status = 'success';
      } catch (err: any) {
        if (err.message?.includes("API_KEY_ERROR")) {
          // @ts-ignore
          await window.aistudio.openSelectKey();
          img.status = 'error';
          img.error = "API Key error. Please retry.";
        } else {
          img.status = 'error';
          img.error = err.message || "Model restricted";
        }
      }
      setBatch([...updatedBatch]);
    }
    
    setStatus(AppStatus.SUCCESS);
  };

  const downloadImage = (url: string, id: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = `kiran-restored-${id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const reset = () => {
    setStatus(AppStatus.IDLE);
    setBatch([]);
    setError(null);
    setCustomPrompt("");
    setCurrentIndex(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-500 ${isProMode ? 'bg-black' : 'bg-slate-950'}`}>
      <nav className="border-b border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 bg-slate-900/40 backdrop-blur-xl z-40">
        <div className="flex items-center gap-2 cursor-pointer" onClick={reset}>
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shadow-lg transition-all duration-500 ${isProMode ? 'bg-indigo-600 shadow-indigo-500/20 rotate-12' : 'bg-amber-500 shadow-amber-500/20'}`}>
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-7.714 2.143L11 21l-2.286-6.857L1 12l7.714-2.143L11 3z" />
            </svg>
          </div>
          <span className="font-bold text-xl tracking-tight text-white">Kiran <span className={isProMode ? 'text-indigo-400' : 'text-amber-400'}>{isProMode ? 'PRO' : 'AI'}</span></span>
        </div>

        <div className="flex items-center gap-6">
           <div className="flex items-center gap-3 bg-slate-900/80 p-1 rounded-full border border-white/10">
              <button 
                onClick={() => setIsProMode(false)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${!isProMode ? 'bg-amber-500 text-black shadow-lg' : 'text-slate-500 hover:text-white'}`}
              >
                Standard
              </button>
              <button 
                onClick={() => {
                  setIsProMode(true);
                  checkAndOpenKeySelector();
                }}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${isProMode ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/40' : 'text-slate-500 hover:text-white'}`}
              >
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                Ultra Pro
              </button>
           </div>
           <div className="h-4 w-px bg-slate-800 hidden sm:block"></div>
           <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="text-slate-500 hover:text-amber-400 text-[10px] font-bold uppercase tracking-wider transition-colors">Billing Doc</a>
        </div>
      </nav>

      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {status === AppStatus.IDLE && (
            <div className="text-center py-12 md:py-20">
              <div className={`inline-block mb-4 px-4 py-1.5 rounded-full border text-xs font-bold uppercase tracking-widest animate-fade-in ${isProMode ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400' : 'bg-amber-500/10 border-amber-500/20 text-amber-500'}`}>
                {isProMode ? 'Next-Gen 4K Neural Reconstruction' : 'Standard Texture Harmonization Engine'}
              </div>
              <h1 className="text-5xl md:text-8xl font-black mb-6 tracking-tighter text-white">
                {isProMode ? 'Ultra ' : 'Deep '}
                <span className={isProMode ? 'text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400' : 'gradient-text'}>
                  {isProMode ? 'Pro Restore' : 'Surface Polish'}
                </span>
              </h1>
              <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto mb-12 leading-relaxed font-light">
                {isProMode 
                  ? "Leveraging Gemini 3 Pro for unmatched clarity, noise-free upscaling, and perfect texture synthesis. Pro subscription required." 
                  : "Standard neural polish for cleaning overlays and smoothing textures. Fast and efficient."}
              </p>
              
              <div className="relative group max-w-2xl mx-auto">
                <div className={`absolute -inset-1 rounded-3xl blur opacity-25 group-hover:opacity-60 transition duration-1000 ${isProMode ? 'bg-gradient-to-r from-indigo-500 to-purple-600' : 'bg-gradient-to-r from-amber-500 to-orange-600'}`}></div>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`relative glass rounded-3xl p-16 flex flex-col items-center justify-center border-2 border-dashed transition-all cursor-pointer ${isProMode ? 'border-indigo-500/30 hover:border-indigo-500' : 'border-slate-700 hover:border-amber-500'}`}
                >
                  <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform ${isProMode ? 'bg-indigo-900/50' : 'bg-slate-800'}`}>
                    <svg className={`w-10 h-10 ${isProMode ? 'text-indigo-400' : 'text-amber-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold mb-2 text-white">Upload Batch</h3>
                  <p className="text-slate-500 mb-8">{isProMode ? 'Processes up to 10 images with Ultra-HD results.' : 'Processes up to 10 images with Standard polish.'}</p>
                  <button className={`px-10 py-4 rounded-2xl font-bold transition-all shadow-xl ${isProMode ? 'bg-indigo-600 text-white hover:bg-indigo-500' : 'bg-amber-500 text-black hover:bg-amber-400'}`}>
                    Choose Files
                  </button>
                  <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" multiple />
                </div>
              </div>
            </div>
          )}

          {status === AppStatus.PREVIEW && (
            <div className="grid lg:grid-cols-3 gap-8 items-start animate-fade-in">
              <div className="lg:col-span-2 space-y-6">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {batch.map((img) => (
                    <div key={img.id} className={`relative aspect-square rounded-2xl overflow-hidden border bg-slate-900 group ${isProMode ? 'border-indigo-500/20 shadow-lg shadow-indigo-500/5' : 'border-slate-800'}`}>
                      <img src={img.originalUrl} className="w-full h-full object-cover" alt="Preview" />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                         <span className="text-white text-[10px] font-bold uppercase tracking-wider">Queue: {img.id.slice(0,4)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="space-y-6 sticky top-24">
                <div className="glass rounded-3xl p-8 border border-white/5 shadow-2xl">
                   <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-white">Neural Config</h3>
                      <span className={`text-xs px-2 py-1 rounded font-bold ${isProMode ? 'bg-indigo-500/20 text-indigo-400' : 'bg-slate-800 text-slate-300'}`}>{batch.length} Units</span>
                   </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-slate-400 mb-3 uppercase tracking-wider">Restoration Goal</label>
                      <textarea 
                        value={customPrompt}
                        onChange={(e) => setCustomPrompt(e.target.value)}
                        placeholder="E.g., Match the fabric texture perfectly..."
                        className={`w-full bg-black/40 border rounded-2xl p-4 text-white placeholder-slate-600 focus:outline-none transition-all text-sm min-h-[120px] ${isProMode ? 'border-indigo-500/30 focus:ring-2 focus:ring-indigo-500' : 'border-slate-700 focus:ring-2 focus:ring-amber-500'}`}
                      />
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {QUICK_PROMPTS.map((p, idx) => (
                        <button 
                          key={idx}
                          onClick={() => setCustomPrompt(p.text)}
                          className={`text-[10px] font-bold uppercase tracking-tighter px-3 py-2 rounded-lg border transition-all ${customPrompt === p.text ? (isProMode ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-amber-600 border-amber-500 text-white') : 'border-slate-800 text-slate-500 hover:border-slate-600 hover:text-slate-300'}`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>

                    <div className="pt-6">
                      <button 
                        onClick={startBatchEnhancement}
                        className={`w-full py-4 rounded-2xl font-black text-lg shadow-xl transition-all flex items-center justify-center gap-3 ${isProMode ? 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-500/20' : 'bg-amber-500 text-black hover:bg-amber-400 shadow-amber-500/20'}`}
                      >
                        {isProMode ? 'Start Pro Engine' : 'Execute Restoration'}
                      </button>
                      <button onClick={reset} className="w-full mt-4 text-slate-500 hover:text-white text-xs font-bold uppercase tracking-widest">
                        Cancel Batch
                      </button>
                    </div>
                  </div>
                </div>
                
                {isProMode && (
                  <div className="p-4 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 flex items-start gap-3">
                     <div className="text-indigo-500 mt-1">
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                        </svg>
                     </div>
                     <p className="text-[10px] text-slate-400 leading-normal uppercase tracking-wide">
                       PRO mode uses Google Gemini 3 Pro. Ensure your selected API key belongs to a paid GCP project to avoid quota errors.
                     </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {status === AppStatus.PROCESSING && (
            <div className="min-h-[600px] relative flex flex-col items-center justify-center animate-fade-in">
              <ProcessingOverlay />
              <div className="z-[60] mt-48 text-center">
                <p className="text-white font-bold text-2xl mb-2">{isProMode ? 'Pro Reconstruction' : 'Syncing Unit'} {currentIndex + 1} of {batch.length}</p>
                <div className="w-64 h-1.5 bg-slate-900 rounded-full mx-auto overflow-hidden border border-slate-800">
                   <div 
                      className={`h-full transition-all duration-500 ${isProMode ? 'bg-indigo-500' : 'bg-amber-500'}`} 
                      style={{ width: `${((currentIndex + 1) / batch.length) * 100}%` }}
                   ></div>
                </div>
              </div>
            </div>
          )}

          {status === AppStatus.SUCCESS && (
            <div className="space-y-12 animate-in fade-in zoom-in duration-700 pb-20">
               <div className={`flex flex-col md:flex-row justify-between items-center gap-4 p-8 rounded-3xl border ${isProMode ? 'bg-indigo-950/20 border-indigo-500/20' : 'bg-slate-900/50 border-slate-800'}`}>
                  <div>
                    <h2 className="text-3xl font-bold text-white">Restoration Success</h2>
                    <p className="text-slate-500 text-sm">Processed {batch.filter(b => b.status === 'success').length} assets with {isProMode ? 'Ultra-HD' : 'Standard'} engine.</p>
                  </div>
                  <button onClick={reset} className="px-8 py-4 bg-white text-black hover:bg-slate-200 rounded-2xl font-bold transition-all shadow-lg">
                    New Session
                  </button>
               </div>

               <div className="grid gap-20">
                 {batch.map((img) => (
                   <div key={img.id} className="space-y-6">
                      {img.status === 'success' && img.enhancedUrl ? (
                        <>
                          <div className="flex justify-between items-end border-b border-white/5 pb-4">
                             <div>
                               <span className="text-[10px] font-bold text-slate-600 uppercase tracking-widest block mb-1">UNIT SERIAL</span>
                               <span className="text-sm font-mono text-slate-400">{img.id}</span>
                             </div>
                             <div className="flex gap-4">
                               <button 
                                 onClick={() => downloadImage(img.enhancedUrl!, img.id)}
                                 className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${isProMode ? 'bg-indigo-600 text-white hover:bg-indigo-500' : 'bg-slate-800 hover:bg-slate-700 text-amber-500'}`}
                               >
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                  </svg>
                                  Download Result
                               </button>
                             </div>
                          </div>
                          <ComparisonSlider before={img.originalUrl} after={img.enhancedUrl} />
                        </>
                      ) : (
                        <div className="p-16 glass rounded-3xl border border-red-500/10 text-center bg-red-500/[0.02]">
                           <div className="w-12 h-12 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                              </svg>
                           </div>
                           <h4 className="text-red-400 font-bold text-xl mb-3">Unit Restricted</h4>
                           <p className="text-slate-500 text-sm max-w-md mx-auto leading-relaxed">{img.error || "Complexity threshold exceeded."}</p>
                           <button onClick={reset} className="mt-8 text-xs font-bold text-slate-600 hover:text-slate-400 uppercase tracking-widest">Return to Upload</button>
                        </div>
                      )}
                   </div>
                 ))}
               </div>
            </div>
          )}

          {error && (
            <div className="fixed bottom-8 right-8 z-[100] bg-red-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 animate-in slide-in-from-bottom-full border border-red-400/20">
               <span className="font-bold text-sm">{error}</span>
               <button onClick={() => setError(null)} className="ml-4 text-white/50 hover:text-white">✕</button>
            </div>
          )}
        </div>
      </main>
      
      <footer className="py-10 border-t border-white/5 text-center">
         <p className="text-slate-600 text-[10px] uppercase tracking-[0.2em]">© 2025 Kiran Neural Laboratory • {isProMode ? 'Ultra-HD Series' : 'Standard Series'}</p>
      </footer>

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default App;
