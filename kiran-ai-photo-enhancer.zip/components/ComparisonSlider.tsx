
import React, { useState, useRef, useEffect } from 'react';

interface ComparisonSliderProps {
  before: string;
  after: string;
}

const ComparisonSlider: React.FC<ComparisonSliderProps> = ({ before, after }) => {
  const [sliderPos, setSliderPos] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const position = ((x - rect.left) / rect.width) * 100;
    setSliderPos(Math.min(Math.max(position, 0), 100));
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full aspect-video md:aspect-auto md:h-[600px] overflow-hidden rounded-2xl cursor-col-resize select-none border border-slate-700 shadow-2xl bg-slate-900"
      onMouseMove={handleMove}
      onTouchMove={handleMove}
    >
      {/* After (Enhanced) Image */}
      <img 
        src={after} 
        alt="After" 
        className="absolute inset-0 w-full h-full object-contain"
      />

      {/* Before (Original) Image */}
      <div 
        className="absolute inset-0 w-full h-full overflow-hidden border-r-2 border-white/50 z-10"
        style={{ width: `${sliderPos}%` }}
      >
        <img 
          src={before} 
          alt="Before" 
          className="absolute inset-0 w-full h-full object-contain filter grayscale-[0.2]"
          style={{ width: `${100 / (sliderPos / 100)}%`, maxWidth: 'none' }}
        />
        <div className="absolute top-4 left-4 bg-black/60 text-white text-xs px-2 py-1 rounded uppercase tracking-widest font-bold">Original</div>
      </div>

      {/* Labels */}
      <div className="absolute top-4 right-4 bg-indigo-600 text-white text-xs px-2 py-1 rounded uppercase tracking-widest font-bold z-20">AI Enhanced</div>

      {/* Slider Handle */}
      <div 
        className="absolute top-0 bottom-0 z-30 flex items-center justify-center pointer-events-none"
        style={{ left: `${sliderPos}%` }}
      >
        <div className="w-1 h-full bg-white shadow-xl"></div>
        <div className="absolute w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center -translate-x-1/2">
          <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7l-4 4m0 0l4 4m-4-4h18m-6 0l4-4m-4 4l4 4" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default ComparisonSlider;
