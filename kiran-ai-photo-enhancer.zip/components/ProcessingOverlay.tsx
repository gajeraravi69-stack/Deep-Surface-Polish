
import React, { useState, useEffect } from 'react';

const messages = [
  "Initializing Kiran Neural Restoration...",
  "Analyzing artificial overlays for cleaning...",
  "Inpainting obscured regions...",
  "Synthesizing high-frequency details...",
  "Reconstructing edges and light paths...",
  "Deep upscaling to Ultra-HD resolution...",
  "Finalizing neural color grading...",
];

const ProcessingOverlay: React.FC = () => {
  const [msgIdx, setMsgIdx] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMsgIdx((prev) => (prev + 1) % messages.length);
    }, 2800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/90 backdrop-blur-xl rounded-2xl border border-slate-800">
      <div className="relative w-28 h-28 mb-10">
        <div className="absolute inset-0 rounded-full border-4 border-t-amber-500 border-amber-500/10 animate-spin"></div>
        <div className="absolute inset-4 rounded-full border-4 border-b-amber-400 border-amber-400/10 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
        <div className="absolute inset-8 rounded-full bg-amber-500/5 flex items-center justify-center">
           <div className="w-2 h-2 bg-amber-500 rounded-full animate-ping"></div>
        </div>
      </div>
      
      <h3 className="text-2xl font-bold mb-3 text-white tracking-tight">Kiran Neural Engine</h3>
      <p className="text-slate-400 animate-pulse text-base font-medium h-6">
        {messages[msgIdx]}
      </p>
      
      <div className="mt-16 w-80 h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
        <div className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-amber-600 w-full animate-[progress_3s_ease-in-out_infinite]"></div>
      </div>

      <style>{`
        @keyframes progress {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

export default ProcessingOverlay;
